package mesressources;

import org.javatuples.Pair;

public class Etudiants {
	static Pair <String, Integer> afficherEtudiant(String nom, Integer age){
		final Pair<String, Integer> etudiant = Pair.with(nom, age);
		return etudiant;
	}
}
