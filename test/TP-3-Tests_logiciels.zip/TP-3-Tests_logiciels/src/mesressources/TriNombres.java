package mesressources;

import java.util.Arrays;

public class TriNombres {
	static int [] trierNombre(final int [] input) {
		Arrays.sort(input);
		return input;
	}
}
