package mesressources;

import static org.junit.jupiter.api.Assertions.*;

import org.javatuples.Pair;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;

class EnseignantTest {
	@ParameterizedTest(name = "Enseignant nomme {0} est age de {1} ans")
	@CsvFileSource(resources = "enseignant.csv")
	void testCsvAfficherEnseignant(final String nom, final int age) {
		final Pair <String, Integer> enseignant = Enseignant.afficherEnseignant(nom, age);
		assertEquals(enseignant.getValue0(), nom);
		assertEquals(enseignant.getValue1(), age);
		System.out.print("Enseignant = "+ enseignant);
		System.out.print("=========================");
	}
	
	@ParameterizedTest(name = "Enseignant nomme {0} est age de {1} ans")
	@CsvSource({"Thomas, 28", "Fatou, 30"})
	void testCsvFileAfficherEnseignant(final String nom, final int age) {
		final Pair <String, Integer> enseignant = Enseignant.afficherEnseignant(nom, age);
		assertEquals(enseignant.getValue0(), nom);
		assertEquals(enseignant.getValue1(), age);
		System.out.print("Enseignant = "+ enseignant);
		System.out.print("=========================");
	}


}
