package mesressources;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestsParametres {
	static boolean estPair(final int i) {
		return (i%2==0);
	}
	
	public double calculRacineCarre(double i) {
		assertEquals(Math.sqrt(i), calculRacineCarre(i));
		return i;
		
	}
	
}
