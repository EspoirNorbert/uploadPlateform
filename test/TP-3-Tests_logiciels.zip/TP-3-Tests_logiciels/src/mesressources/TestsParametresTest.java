package mesressources;

import static org.junit.jupiter.api.Assertions.*;

//import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class TestsParametresTest extends TestsParametres {
	@ParameterizedTest (name="La racine carre de {i} est: {}")
	@ValueSource(ints= {2,4,6})
	void testcalculRacineCarre(double i) {
		System.out.print("Le teste reussit");
	}

}
