package mesressources;

import static org.junit.jupiter.api.Assertions.*;

import org.javatuples.Pair;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

class EtudiantsTest {

	@ParameterizedTest(name = "Etudiant nomme {0} et age de {1}")
	@CsvSource({"Thomas, 28", "Fatou, 30"})
	void testCsvAfficherEtudiant(final String nom, final int age) {
		final Pair <String, Integer> etudiant = Etudiants.afficherEtudiant(nom, age);
		assertEquals(etudiant.getValue0(), nom);
		assertEquals(etudiant.getValue1(), age);
		System.err.println("Etudiant = "+ etudiant);
	}

}
