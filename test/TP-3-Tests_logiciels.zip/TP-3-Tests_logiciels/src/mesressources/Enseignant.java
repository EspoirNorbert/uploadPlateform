package mesressources;

import org.javatuples.Pair;

public class Enseignant {
	static Pair <String, Integer> afficherEnseignant(String nom, Integer age){
		final Pair<String, Integer> enseignant = Pair.with(nom, age);
		return enseignant;
	}

}
