package mesressources;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class TriNombresTest {

	/*@ParameterizedTest(name = "{0} est trie en {1}")
	@MethodSource("dataProvider")
	void testDtaProvider(final int [], final int [] expected) {
		TriNombres.trierNombre(input);
		assertArrayEquals(expected, input);
	}
	
	static Stream<Arguments> dataProvider(){
		return Stream.of(
				arguments(new int [] {1,2,3}, new int [] {1,2,3}),
				arguments(new int [] {1,2,3}, new int [] {1,2,3}),
				arguments(new int [] {1,2,3}, new int [] {5,5,5})
				);
	}*/

}
