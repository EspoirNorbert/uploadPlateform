package com.sunutv.emissions;

public class Reportage extends Emission {
	private Theme theme ;

	public Reportage(String nom, Theme theme, int duree) {
		super(nom);
		this.theme = theme;
		if(duree <= 0) this.duree = 1;
		else this.duree = duree;
	}
}
