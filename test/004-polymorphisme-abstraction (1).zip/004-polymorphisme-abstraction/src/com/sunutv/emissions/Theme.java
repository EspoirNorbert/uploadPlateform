package com.sunutv.emissions;

public enum Theme {
	INFORMATION , ANIMALIER , CULTUREL
}
