package com.sunutv.emissions;

public abstract class Emission {
	protected String nom ;
	protected int duree ;
	protected int debut ; 
	protected int fin ;
	
	public Emission(String nom) {
		this.nom = nom;
	}
}
