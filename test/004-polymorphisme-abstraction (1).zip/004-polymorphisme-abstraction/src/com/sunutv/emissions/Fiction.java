package com.sunutv.emissions;

public class Fiction extends Emission {
	private int annee ;
	private String realisateur;
	private boolean rediffusion;
	
	public Fiction(String nom, int annee, String realisateur, boolean rediffusion , int duree) {
		super(nom);
		if (annee >= 1970 && annee <= 2020) this.annee = annee;
		else this.annee = 2020;
		this.realisateur = realisateur;
		this.rediffusion = rediffusion;
		if (duree <= 0 ) this.duree = 1;
		else this.duree = duree;
	}
	
}
