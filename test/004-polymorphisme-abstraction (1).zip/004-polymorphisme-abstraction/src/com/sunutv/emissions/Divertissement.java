package com.sunutv.emissions;

public class Divertissement extends Emission {
	private String animateur;
	public static final int DUREE = 2 ;
	
	public Divertissement(String nom, String animateur) {
		super(nom);
		this.setAnimateur(animateur);
		this.duree = DUREE;
	}

	public String getAnimateur() {
		return animateur;
	}

	public void setAnimateur(String animateur) {
		this.animateur = animateur;
	}
	
}
