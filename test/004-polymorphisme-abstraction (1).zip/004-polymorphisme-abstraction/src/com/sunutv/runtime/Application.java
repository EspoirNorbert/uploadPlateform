package com.sunutv.runtime;

import com.sunutv.emissions.Divertissement;
import com.sunutv.emissions.Fiction;
import com.sunutv.emissions.Reportage;
import com.sunutv.emissions.Theme;

public class Application {

	public static void main(String[] args) {
		Divertissement d = new Divertissement("Confrontation","Bijou");
		Fiction f = new Fiction ("Takaka",2010,"Ivan",false,3);
		Reportage r = new Reportage ("Sept à huit", Theme.INFORMATION, 1);

	}

}
