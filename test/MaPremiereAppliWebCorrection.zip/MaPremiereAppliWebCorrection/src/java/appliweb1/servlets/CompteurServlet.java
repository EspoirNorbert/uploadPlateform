package appliweb1.servlets;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Cette servlet retourne l'image d'un compteur, chaque fois que cette servlet
 * est exécutée, le compteur est incrémenté.
 *
 * la requête HTTP peut contenir un paramètre "size" qui défini la taille de la
 * police utilsiée pour le compteur. Par défaut cette taille est de 24 points.
 *
 * @author Philippe Genoud - UGA Université Grenoble Alpes - Lab. LIG Steamer
 */
@WebServlet(name = "CompteurServlet", urlPatterns = {"/compteur"})
public class CompteurServlet extends HttpServlet {

    /**
     * compteur du nombre de fois où la methode process request est exécutée
     */
    private static int nbPassages = 0;

    // tailles utilisées pour le buffer qui sert à construire l'image du compteur
    private static final int BUFFER_HEIGHT = 400;
    private static final int BUFFER_WIDTH = 800;

    // taille de police par défaut pour le comtpeur
    private static final int FONT_SIZE = 24;

    /**
     * Crée en mémoire une image de compteur
     *
     * @param compteur la valeur du compteur à afficher
     * @param fontSize la taille de la police du compteur
     * @param backgroundColor couleur du fond de l'image
     * @param textColor couleur du texte
     * @return l'image
     */
    private BufferedImage createImageCompteur(int compteur, int fontSize,
            Color backgroundColor, Color textColor) {
        String formattedCounter = String.format("%06d", compteur);
        BufferedImage buffer = new BufferedImage(BUFFER_WIDTH, BUFFER_HEIGHT, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = buffer.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(new Font("Monospaced", Font.BOLD, fontSize));
        FontMetrics fm = g.getFontMetrics();
        g.setColor(backgroundColor);   // la couleur du fond
        g.fillRect(0, 0, BUFFER_WIDTH, BUFFER_HEIGHT);
        g.setColor(textColor); // la couleur du texte
        g.drawString(formattedCounter, 5, BUFFER_HEIGHT - 5);
        int compteurHeight = fm.getAscent();
        int compteurWidth = fm.stringWidth(formattedCounter);
        return buffer.getSubimage(0, BUFFER_HEIGHT - compteurHeight, compteurWidth + 10, compteurHeight);
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        int fontSize = FONT_SIZE;
        // si il existe on récupère la valeur du paramètre size qui définit 
        // la taille de la police
        if (request.getParameter("size") != null) {
            Integer.parseInt(request.getParameter("size"));
        }
        BufferedImage image;

        synchronized (this) {
            // on utilise un bloc synchronisé, les servlets étant multithreadés
            // cela évite que le compteur de passages puisse être modifié avant
            // que l'image correspondante ne soit générée.
            nbPassages++;
            image = createImageCompteur(nbPassages, fontSize, Color.BLACK, Color.WHITE);
        }

        // envoie l'image sur la sortie de la servlet
        try (OutputStream out = response.getOutputStream()) {
            // fixe le type MIME pour indiquer que la réponse est une image au format PNG
            response.setContentType("image/png");
            // Encode l’image en png et l’écrit sur le flux binaire de la réponse
            ImageIO.write(image, "png", out);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
