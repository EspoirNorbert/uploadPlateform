package appliweb1.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <p>
 * Cette servlet traite une requête HTTP de type GET ou POST comportant deux
 * paramètres</p>
 * <ul>
 * <li>texte : un texte à afficher</li>
 * <li>nbRepet : le nombre de fois où ce texte est à afficher.</li>
 * </ul>
 * <p>
 * Elle renvoie une page HTML affichant le jour et l'heure et nbRepet fois la valeur
 * du paramètre texte.
 * </p>
 *
 * @author Philippe Genoud - LIG STeamer - UJF
 */
@WebServlet(name = "HelloWorldServlet", urlPatterns = {"/helloworld"})
public class HelloWorldServlet extends HttpServlet {

    /**
     * traite les requêtes de type HTTP <code>GET</code> and <code>POST</code>.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // recupération des paramètres de la requête
        String texte = request.getParameter("texte");
        int nbRepetitions = Integer.parseInt(request.getParameter("nbRepet"));

         /* génération de la réponse HTML */ 
        try (PrintWriter out = response.getWriter()) {

            response.setContentType("text/html;charset=UTF-8");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet HelloWorldServlet</title>");
            out.println("</head>");
            out.println("<body>");
            for (int i = 0; i < nbRepetitions; i++) {
                out.println("<h1>Hello " + texte + " ! </h1>");
            }
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMMMM yyyy ', il est ' hh:mm ",
                    new Locale("en"));
            Date currentDate = new Date();
            out.println("Nous sommes le " + dateFormat.format(currentDate));
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
