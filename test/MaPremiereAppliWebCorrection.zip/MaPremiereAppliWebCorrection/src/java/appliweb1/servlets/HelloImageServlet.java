package appliweb1.servlets;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Cette servlet retourne une image PNG d'un texte.
 *
 * <p>les paramètres de la requète HTTP qui définissent l'image sont, comme pour la
 * servlet HelloWordlServlet : </p>
 * <ul>
 *    <li>texte : un texte à afficher</li>
 *    <li>nbRepet : le nombre de fois où ce texte est à afficher. Le texte sera
 *     affiché en le faisant pivoter n fois par rapport au centre de l'image.
 *    </li>
 * </ul>
 *
 * @author Philippe Genoud - UGA Université Grenoble Alpes - Lab. LIG Steamer
 */
@WebServlet(name = "DrawHelloServlet", urlPatterns = {"/helloimage"})
public class HelloImageServlet extends HttpServlet {

    /**
     * Crée une image en mémoire où le message à afficher est dessiné n fois en
     * pivotant par rapport au centre de l'image (qui est carrée)
     *
     * @param size taille de l'image
     * @param msg la message à afficher
     * @param nbRepetition le nombre de répétitions du message
     * @param backgroundColor couleur du fond de l'image
     * @param textColor couleur du texte
     * @return l'image
     */
    BufferedImage createImage(int size, String msg, int nbRepetition,
            Color backgroundColor, Color textColor) {
        BufferedImage buffer = new BufferedImage(size, size, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = buffer.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g.setFont(new Font("Monospaced", Font.BOLD, 24));
        g.setColor(backgroundColor);   // la couleur du fond
        g.fillRect(0, 0, size, size);
        g.setColor(textColor); // la couleur du texte
        g.drawString(msg, size / 2 + 20, size / 2);
        for (int i = 0; i < nbRepetition; i++) {
            Graphics2D g1 = (Graphics2D) g.create();
            double angle = (i * 2 * Math.PI) / nbRepetition;
            g1.rotate(angle, size / 2, size / 2);
            g1.translate(size / 2 + 20, size / 2);
            g1.drawString(msg, 0, 0);
        }
        return buffer;
    }

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // recupération des paramètres de la requête
        String texte = request.getParameter("texte");
        int nbRepetitions = Integer.parseInt(request.getParameter("nbRepet"));
        // génération de l'image
        BufferedImage image = createImage(500, texte, nbRepetitions, Color.LIGHT_GRAY, Color.BLACK);
        // fixe le type MIME pour indiquer que la réponse est une image au format PNG
        // ecriture de l'image sur la sortie de la servlet
        try (OutputStream out = response.getOutputStream()) {
            response.setContentType("image/png");
            // Encode l’image en png et l’écrit sur le flux binaire de la réponse
            ImageIO.write(image, "png", out);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
