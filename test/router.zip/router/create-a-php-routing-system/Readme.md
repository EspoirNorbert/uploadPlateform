# Create a PHP Routing Sytem

![Create a PHP Routing System](https://devdojo.com/uploads/images/October2017/create-a-simple-php-router-sd.jpg)

This is the source code for the video series located at: https://devdojo.com/series/create-a-php-routing-system

In this video series you will learn how to create a very simple PHP routing system.
