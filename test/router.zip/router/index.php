<?php
//get uri 
$uri = $_SERVER["REQUEST_URI"];
//trim uri
$route = trim($uri, '/');
//scinde la chaine de caractere en le separons par les /
$uri = explode('/', $uri);

/* //recupere le premier */
echo $uri[0] . '<br>';

print_r($uri); 
if($uri[0] == $route ){

    array_shift($uri);
    require './pages/home.php';
}