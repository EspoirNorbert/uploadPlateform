<footer>
   
  <div class="text-center text-light p-3" style="background-color: rgba(0, 0, 0, 0.7);">
    © 2021 Copyright:
    <a class="text-light" href="index.php">Gestion de Produits</a>
  </div>
   
</footer>