<?php
include('header.php');
?>

<html>
  <head>
	  <title>Index</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="style.css">
	  <link rel="stylesheet" type="text/css" href="./css/bootstrap.min.css">
  </head>
  <body>

 
  
  <h2>Bienvenue <br> sur <br> l'application web <br> de gestion de produits</h2> <br>
  Cette application web vous permettra de gerer avec facilité <br>les produits. <br> <br>
  Grace a cette application on peut Afficher la liste des produits existants  <br> Adjouter des produits <br>
  Afficher les details des produits, les Modifier ou encore les Supprimer.
  

 
  	<script type="text/javascript" src="./js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="./js/bootstrap.min.js"></script>
  </body>
</html>
<?php
include('footer.php');
?>