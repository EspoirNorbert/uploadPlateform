<?php 
namespace Utilisateur\Administrateur;
//pour utiliser directement un namespace sans specifier le namespaceon 
//utilise le use
use App\Utilisateur ;

require_once "./Utilisateur.php";
require "./IConnexion.php";

class Admin extends Utilisateur implements \IConnexion{
    private $login ;
    private $password;

    public function seConnecter($login , $password){
       if(empty($login) && empty($password)){
           throw new \Exception("Veuillez remplir tous les champs svp");
       }
       else if (empty($login) ){
           throw new \Exception("Veuiller inserer un login");
       }
       else if(empty($password)){
           throw new \Exception("Veuillez inserer un mot de passe", 1);
       }
       else if($login == "admin" && $password == "admin"){
           echo "Bravo!! vous etes bien connecté";
       }
       else {
           echo "info incorrect" . PHP_EOL;
       }
    }

    public function getLogin(){
        return $this->login;
    }

    public function getPassword(){
        return $this->password;
    }
    
    public function afficherInfo(){
        echo "je suis un admin je m'appelle {$this->prenom} {$this->nom} j'ai {$this->age} ans je suis en troisieme licence a ". Utilisateur::ECOLE." en  specialite ". Utilisateur::CLASSE . PHP_EOL;
    }

}