<?php 
use App\Utilisateur;
require_once './Utilisateur.php';
require_once './Admin.php';

try {
    $marie = new Utilisateur("Marie","Therese",7);

    $marie->afficherInfo();

    $luc = new Utilisateur("Luc","Oeudraogo",28);
    $luc->afficherInfo();

    Utilisateur::afficherNbUtilisateur();
    PHP_EOL;
    $luc->__destruct();

    Utilisateur::afficherNbUtilisateur();

    $admin =  new \Utilisateur\Administrateur\Admin("Augusto","BASSAM",20);
    $admin->afficherInfo();


    $admin->seConnecter("admin",'admin');

} catch (\Throwable $e) {
     echo $e->getMessage();
}

