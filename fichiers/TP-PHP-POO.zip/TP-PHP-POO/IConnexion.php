<?php 
interface IConnexion {
    public function seConnecter($login , $password);
}


?>