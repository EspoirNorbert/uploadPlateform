<?php 

namespace App;

class Utilisateur {
    protected  $nom;
    protected $prenom;
    protected $age;
    const CLASSE = 'DAR';
    const ECOLE = 'ESMT';
    const ANNEE = 3;
    public static $nbUtilisateur;

    public function __construct($nom,$prenom,$age) {
        $this->nom = $nom;
        $this->prenom = $prenom;
        $this->setAge($age) ;
        $this::$nbUtilisateur++;
    }

    public function __destruct()
    {
        $this->remove();
    }

    protected function remove(){
        $this::$nbUtilisateur--;
    }

    public function getNom()
    {
       return $this->nom;
    }

    public function setNom($nom)
    {
       $this->nom = $nom;
    }

    public function getPrenom()
    {
       return $this->prenom;
    }

    public function getAge()
    {
       return $this->age;
    }

    public function setAge($age){
        if($age < 0 ){
            throw new \Exception("l'age doit etre positif");
        }
    }

    public function afficherInfo(){
        echo "je m'appelle {$this->prenom} {$this->nom} j'ai {$this->age} ans je suis en troisieme licence a ". Utilisateur::ECOLE." en  specialite ". Utilisateur::CLASSE . PHP_EOL;
    }

    public static function afficherNbUtilisateur()
    {
        echo "il y'a ". self::$nbUtilisateur." utilisateur dans le systeme".PHP_EOL;
    }
}