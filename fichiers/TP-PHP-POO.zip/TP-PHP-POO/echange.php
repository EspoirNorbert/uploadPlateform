<?php
//JSON
$json='
{ "client":[
   {"id":1, "nom":"DIOP"},
   {"id":2, "nom":"FAYE"},
   {"id":3, "nom":"DIOUF"}
]
}';
$parse = json_decode($json);
foreach($parse as $elt){

    foreach($elt as $value){
        //afficher le nom et l'id 
        echo "<p>[client: id=".$value->id.";nom=".$value->nom."]</p>";
        }
       
}
echo "<p>".$parse->client[0]->nom."</p>";
//recuperer les donnees de la base de donnees mettez ces derniers dans 
//fichiers json et recuperer afficher les a partir du javascript

//$file = fopen("./client.json","r");

$json = file_get_contents("client.json");

$cotention = file_get_contents("cotation_bourse.json");

$bourse = json_decode($cotention);

var_dump($bourse->cotation_bourse[0]->bourse);

$parse_client = json_decode($json);

$nomClient = $parse_client[0]->nom;

echo $nomClient;

$client1 = $parse->client[0];
//echo json_encode($client1);


//XML
//l'objet simple_xml_load_file
$xml=simplexml_load_file("clients.xml");
echo"<p>".$xml->count()." enfants trouvés</p>";

/* var_dump($xml->children()); */

die();
$i=0;
foreach($xml->children() as $child){
    $i++;
    echo"<p>Enfant $i:</p>";
    foreach($child->attributes() as $key=>$value){
    echo"<p>$key=$value</p>";
    }
}
//ajout d'un attribut/noeud avec addChild et attributs 
$client4=$xml->addChild('client');
$client4->addAttribute("id",4);
$client4->addAttribute("nom","Diallo");

/* var_dump($xml); */
//la fonction asXML affiche en formar xml
echo $client4->asXML();
$xml->asXML("clients.xml");//Ecrit dans le fichier spécifié

