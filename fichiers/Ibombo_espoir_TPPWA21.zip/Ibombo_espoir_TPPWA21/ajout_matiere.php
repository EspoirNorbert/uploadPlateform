<?php
if(isset($_POST["bajout"])){
    require_once './autoload.php';
     extract($_POST);
     //creation d'un matiere DAO
    $matiereDAO = matiereDAO::getInstance();
    //creation d'un matiere
    $matiere = new matiere();
    //attribut les donnees a l'objet
    $matiere->hydrate([
        'Nomat' => $nomat,
        'Coeff' => $coeff,
        'Numens' => $numens,
    ]);
    //inserer l'matiere
    $ajout = $matiereDAO->create($matiere);
    if($ajout){
       echo  "$nomat a ete bien ajouté " ;
       echo "<a href='liste_matiere.php'><< Retour</a>";
    }
    else{
        echo "Echec d'ajout d'un matiere" ;
        echo "<a href='liste_matiere.php'><< Retour</a>";
    }
}