<?php
//inclure autoload pour charger les classes
 require './autoload.php';
//creation d'un matiereDAO
$matiereDAO = MatiereDAO::getInstance();
//creation d'un Enseignant DAO
$enseignantDAO = EnseignantDAO::getInstance();
//lister les matiere 
$lesMatieres = $matiereDAO->getMatieres();
//lister les matiere 
$lesEnseignants = $enseignantDAO->getEnseignants();
//les noms des Enseignants
$nomsEnseignants = [];
foreach($lesEnseignants as $enseignant){
  //ajout chaque nom selon son indice dans le tableau nomenseignants
  $nomsEnseignants [$enseignant->getNumens()] = $enseignant->getNomens();
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="matiere-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liste des matieres</title>
    <link rel="stylesheet" href="./styles/style.css">
    <link rel="stylesheet" href="./styles/bootstrap.min.css">
</head>
<bodEnseignant>
<?php include './includes/navbar.php' ?>
<div class="container mt-5">
<div class="card border border-primarEnseignant">
   <div class="card-heard  bg-primary">
   <h2 class="text-left text-center p-2  text-white">Liste des matières</h2>
   </div>
<table class="table-content w-100">
  <tr>
      <th>ID</th>
      <th>Matière</th>
      <th>Coefficient</th>
      <th>Enseignant</th>
  </tr>
   <?php 
    foreach($lesMatieres as $matiere){
      echo"<tr>
               <td>{$matiere->getNumat()}</td>
               <td>{$matiere->getNomat()}</td>
               <td>{$matiere->getCoeff()}</td>
               <td>{$nomsEnseignants[$matiere->getNumens()]}</td>
           </tr>" ;
     }
   ?>
  </table>
  </div>
</div>
</bodEnseignant>
</html>