<nav class="navbar navbar-expand-sm bg-primary navbar-dark">
  <a class="navbar-brand" href="index">Cours</a>
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="form_inscription"><button class="btn btn-primary">Ajouter une matiere</button></a>
    </li>
    <li class="nav-item">
    <a class="nav-link" href="liste_matiere.php"><button class="btn btn-primary">Listes des matieres</button></a>
    </li>
  </ul>
</nav>