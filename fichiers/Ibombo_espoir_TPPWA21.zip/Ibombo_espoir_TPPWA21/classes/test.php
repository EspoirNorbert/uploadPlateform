<?php
require_once '../autoload.php';
if(MyPDO::getInstance()){
    echo "ok";
}else{
    echo "Nok";
}