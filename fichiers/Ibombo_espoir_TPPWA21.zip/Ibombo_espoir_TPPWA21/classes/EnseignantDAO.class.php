<?php 
class EnseignantDAO {
  protected $db;
  private static $instance;
  
  public function __construct() {
      $this->db = MyPDO::getInstance();
  }

  public static function getInstance(){
     if(!self::$instance){
         self::$instance = new EnseignantDAO();
     }
     return self::$instance;
  }
  
  //retourne la liste des Enseignant 
  public function getEnseignants(){
    $sql = "select * from enseignant";
    $query = $this->db->query($sql);
    $enseignants = [];
    while($data = $query->fetch(PDO::FETCH_ASSOC)){
     $id = $data['Numens'];
     $enseignant = new Enseignant($id);
     $enseignant->hydrate($data);
     $enseignants[] = $enseignant;
    }
    return $enseignants;
  }

}