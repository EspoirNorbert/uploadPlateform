<?php
class Matiere {
    private $numat; //numat
    private $nomat; //nomat
    private $coeff; //coeff
    private $numens; //numens

    public function __construct($numat = null) {
        $this->numat = $numat;
    }

    //getters et setters
    public function getNumat(){return $this->numat;}
    public function getNomat(){return $this->nomat;}
    public function setNomat(string $nomat){$this->nomat = $nomat;}
    public function getCoeff(){return $this->coeff;}
    public function setCoeff(string $coeff){$this->coeff = $coeff;}
    public function getNumens(){return $this->numens;}
    public function setNumens(int $numens){$this->numens = $numens;}

   //methode hydrate
   public function hydrate(array $data){
    if(isset($data['Nomat'])){
        $this->setNomat($data['Nomat']);
    }
    if(isset($data['Coeff'])){
        $this->setCoeff($data['Coeff']);
    }
    if(isset($data['Numens'])){
        $this->setNumens($data['Numens']);
    }
}
    
}