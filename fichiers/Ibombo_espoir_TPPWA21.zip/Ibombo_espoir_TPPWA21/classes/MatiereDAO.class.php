<?php 
class MatiereDAO {
  protected $db;
  private static $instance;
  
  public function __construct() {
      $this->db = MyPDO::getInstance();
  }

  public static function getInstance(){
     if(!self::$instance){
         self::$instance = new MatiereDAO();
     }
     return self::$instance;
  }

  //inserer une matiere 
  public function create(Matiere $matiere){
    $sql = "insert into matiere values(null,'{$matiere->getNomat()}','{$matiere->getCoeff()}','{$matiere->getNumens()}')";
    return $this->db->exec($sql);
    }

  //liste des matieres
  public function getMatieres(){
    $sql = "select * from matiere";
    $query = $this->db->query($sql);
    $matieres = [];
    while($data = $query->fetch(PDO::FETCH_ASSOC)){
     $id = $data['Numat'];
     $matiere= new Matiere($id);
     $matiere->hydrate($data);
     $matieres[] = $matiere;
    }
   return $matieres;
  }

}