<?php
class Enseignant {
    private $numens; //numens int
    private $nomens; //nomens string
    private $prenomens; //prenomens string
    private $grade; //nomens string
    private $ancien; //nomens int

    public function __construct($numens = null) {
        $this->numens = $numens;
    }
    //getters et setters
    public function getNumens(){return $this->numens;}
    public function getNomens(){return $this->nomens;}
    public function setNomens(string $nomens){$this->nomens = $nomens;}
    public function getPrenomens(){return $this->prenomens;}
    public function setPrenomens(string $prenomens){$this->prenomens = $prenomens;}
    public function getGrade(){return $this->grade;}
    public function setGrade(string $grade){$this->grade = $grade;}
    public function getAncien(){return $this->ancien;}
    public function setAncien(int $ancien){$this->ancien = $ancien;}
 
    //hydrate
   public function hydrate(array $data){
    if(isset($data['Nomens'])){
        $this->setNomens($data['Nomens']);
    }
    if(isset($data['Prenomens'])){
        $this->setPrenomens($data['Prenomens']);
    }
    if(isset($data['Grade'])){
        $this->setGrade($data['Grade']);
    }
    if(isset($data['Ancien'])){
        $this->setAncien($data['Ancien']);
    }
}
}