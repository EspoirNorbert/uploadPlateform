<?php 
require './autoload.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulaire d'ajout d'une matiere</title>
    <link rel="stylesheet" href="./styles/bootstrap.min.css">
</head>
<body>
  <?php include './includes/navbar.php' ?>
    <div class="container mt-5">
    <div class="card w-50 mx-auto border border-primary">
        <div class="card-header bg-primary">
        <h2 class="text-left p-2 text-center text-white">Ajout d'une matiere</h2>
        </div>
        <div class="card-content">
            <form action="ajout_matiere.php" class="p-2" method="post">
                <div class="form-group">
                    <label for="matiere">Matiere</label>
                    <input type="text" placeholder="Entrer la matiere" class="form-control" autofocus required name="nomat">
                </div>
                <div class="form-group">
                <label for="">Coefficient</label>
                <input type="number" placeholder="Entrer le coefficient" class="form-control" required name="coeff">
                </div>
            <div class="form-group">
                <label for="">Enseigant</label>
                <select name="numens" class="form-control" required >
                <option value="null">Selectionnez un enseignant</option>
            <?php 
            $enseignantDAO = EnseignantDAO::getInstance();
            $enseigants = $enseignantDAO->getEnseignants();
            foreach ($enseigants as $enseigant) {
                //var_dump($diplome->getNom());
                echo "<option value='{$enseigant->getNumens()}'>{$enseigant->getNomens()}</option>";
            }
            ?>
        </select>
        </div>
       </div>
        <div class="card-footer bg-primary">
         <div>
            <button class="btn bg-white text-primary  btn-primary btn-lg" name="bajout" type="submit">Ajouter</button>
        </div>
        </div>
        </form>
        </div>
    </div>
</body>
</html>