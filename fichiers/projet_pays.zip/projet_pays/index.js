$(document).ready(function () {
    // inserer  les données 
    $("#bajout").click(insererDonnee);
    function insererDonnee() {
        $("tbody").empty();
        $("#th").removeClass("d-none");
        $.getJSON("https://restcountries.eu/rest/v2/region/africa", function (data) {
            $.each(data, function (i, elt) {
                var ligne = "<tr  style='text-align: center' >";
                ligne += "<td>" + elt.name + "</td>";
                ligne += "<td>" + elt.capital + "</td>";
                ligne += "<td>" + elt.currencies[0].name + "</td>";
                ligne += "<td> <img style= 'width:450px' src=\' " + elt.flag + "\' ></td>";
                ligne += "</tr>";
                $("#tableau").append(ligne);
            });
        });
    }
    //pour la barre de recherche
    $("#recherche").click(function (e) { 
        e.preventDefault();
        $("tbody").empty();
        $("#thead").removeClass("d-none");
        var recherche="https://restcountries.eu/rest/v2/callingcode/"
        recherche += $("#search").val();
        console.log(recherche);
        $.getJSON(recherche, function (data) {
            $.each(data, function (i, elt) {    
                var ligne = "<tr style='text-align: center' >";
                ligne += "<td>" + elt.name + "</td>";
                ligne += "<td>" + elt.capital + "</td>";
                ligne += "<td>" + elt.region + "</td>";
                ligne += "<td>" + elt.subregion + "</td>";
                ligne += "<td>" + elt.population+ "</td>";
                ligne += "<td> <img style= 'width:450px' src=\' " + elt.flag + "\' ></td>";
                ligne += "</tr>";
                $("#array").append(ligne); 
            });
        });
    });;
    
}); 