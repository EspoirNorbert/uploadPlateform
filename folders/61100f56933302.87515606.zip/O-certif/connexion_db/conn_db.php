<?php
//Connexion et sélection de la source de données
$server="localhost";
$user="root";
$pwd="";
$db="dbcertif";
$conn=mysqli_connect($server,$user,$pwd,$db);
?>