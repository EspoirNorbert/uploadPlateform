<?php 
$id_categorie = intval($_GET["formation"]);
//Appel du fichier de connexion à la bd
require_once('connexion_db/conn_db.php');
mysqli_query($conn,"set names 'utf8'");
//Définition de la requête de sélection
$sql_part="select * from formation f natural join categorie where f.id_categorie = $id_categorie";
//Exécution
$query_part = $conn->query($sql_part);

//Définition de la requête de sélection
$sql="select categorie from categorie  where f.id_categorie = $id_categorie";
//Exécution
$query = $conn->query($sql_part);
$nomcate = mysqli_fetch_array($query);
function get_image(int $id_categorie ){
    switch($id_categorie){
        case '1':
            return "developpement-de-logiciels.jpg" ;break;
        case '2':
            return "management.jpg";break;
        case '3':
            return "cloud-computing.png";break;
        case '4':
            return "Cybersécurité-tous-concernés-704x378-vf.png";break;
        default:
            return "elearning.png";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Machi</title>
  <link rel="apple-touch-icon" sizes="180x180" href="img/homeimg/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/homeimg/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/homeimg/favicon-16x16.png">
  <link rel="manifest" href="img/homeimg/site.webmanifest">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/fontawesome-all.min.css" >
    <link rel="stylesheet" href="css/countries.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
</head>
<body>
    <div class="wrapper">
        <div class="slidebar">
            <h2 class="text-uppercase">O-certif</h2>
            <a href="/">
             <img src="img/homeimg/android-chrome-192x192.png" width="100" class="d-block text-center mx-auto mb-3 border border-primary rounded-circle" alt="">
            </a>
            <ul>
                <li><a href="dashboard.php" id="africa" class="nav-link btn btn-outline-primary">Formation Suivie</a></li>   
                    <li><a href="#" id="africa" class="nav-link btn btn-outline-primary">Certificat de formation</a>
            </ul>
            <div class="footer">
                <p>Copyright©2021
                    <a href="sortie.php" class="btn btn-outline-primary title">O-Certif</a>
                </p>
            </div>
        </div>
    </div>
    <div class="container w-75 float-right">
        <h2 class="mt-4">Formation de certification en <?= $nomcate['categorie'] ?></h2>
        <?php
       while($part=mysqli_fetch_array($query_part)){//Tant qu'on extrait des lignes
        extract($part);
        ?>
        <div class="row mt-5 mb-5 d-flex justify-content-center ">
        <div class="col-md-4 border border-primary ">
        <img src="img/homeimg/<?= get_image($id_categorie) ?> " alt="${elt.name}" class="img-fluid border border-primary img-thumbnail mt-3 p-2 rounded">
       </div>
       <div class="col-md-6 border border-primary ">
        <h2 class="title"><?= $libelle ?></h2>
        <table class="table">
            <tr>
                <th>heure</th>
                <td><?= $heure ?></td>
            </tr>
            <tr>
            <th>Niveau</th>
            <td><?= $niveau ?></td>
           </tr>
           <tr>
            <th>Certificat</th>
            <td>disponible</td>
           </tr>
        <tr>
        <th>descriptions</th>
            <td class="w-50">
                <?php 
                if(empty($description)){
                    echo "indisponible";
                }else{
                    echo $description;
                }
                ?>
            </td>
        </tr>
        <tr>
             <td colspan="2" class="text-center w-50"><button class="btn btn-primary">Suivre la formation</button></td>
            </tr>
        </table>
    </div>
    </div>
     <?php
      }
      ?>   
       
      </div>
   
    </div>
</body>
</html>