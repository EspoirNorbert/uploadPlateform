<?php
//Appel du fichier de connexion
require_once('connexion_db/conn_db.php');
//Définition de la requête
$sql_soc="select * from social";
//Exécution de la requête
$query_soc= $conn->query($sql_soc);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Machi</title>
  <link rel="apple-touch-icon" sizes="180x180" href="img/homeimg/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/homeimg/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/homeimg/favicon-16x16.png">
  <link rel="manifest" href="img/homeimg/site.webmanifest">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/style2.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
    integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
</head>
<body>
  <!-- entete -->
  <div class="header">
    <nav class="navbar navbar-expand-sm bg-primary navbar-dark fixed-top">
      <a class="navbar-brand text-uppercase text-weight" href="index.html">
        <img src="img/homeimg/favicon.ico" alt="">
        O-certif</a>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-primary btn btn-primary title mr-auto " href="inscription.php">S'inscrire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-primary  btn btn-primary title ml-3" href="connexion.php">Se connecter</a>
        </li>
      </ul>
    </div>
    </nav> 
  </div>
  <div class="container text-white mt-5 mb-5">
    <h2 class="title text-center border border-primary p-3 w-100 mb-5" style="background-color: rgba(46, 46, 46, 0.863);">Inscription</h2>
    <form action="ajout.php" class="border border-primary p-3 bg-dark" method="post">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="title h4" for="">Nom</label>
                        <input type="text" class="form-control" autofocus required name="nom">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="title h4" for="">Prenom</label>
                        <input type="text" class="form-control" required name="prenom">
                    </div>
                </div>
                <div class="col-md-4">
                  <div class="form-group">
                  <label  class="title h4"  for="">Date de naissance</label>
                  <input type="date" class="form-control" required  name="datenaiss">
                  </div>
              </div>
            </div>
            <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label class="title h4"  for="">Email</label>
                <input type="email" class="form-control"  required name="email">
            </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                <label  class="title h4"  for="">Password</label>
                <input type="password" class="form-control" required  name="password">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                <label class="title h4"  for="">Statut social</label>
                 <select name="social" class="form-control" id="">
                  <option value="etudiant">Etudiant</option>
                  <option value="salarie">Salarie</option>
                 </select>
                </div>
            </div>
            </div>
            <div class="row">
                <div class="text-center offset-md-5 col-md-2">
                    <button class="btn btn-primary btn-lg" name="bajout" type="submit">S'inscrire</button>   
                </div>
                <div class="col-md text-right pt-1">
                    <p>Vous avez déjà un compte ?
                    <a href="connexion.php" class="text-white ">Connectez-vous</a></p>
                </div>
     
            </div>
        </form>
  </div>
  <!-- fin du middle -->
  <div class="footer bg-primary">
    <p>
      Copyright &copy; O-Certif 2021-2022 - All Right reserved
    </p>
  </div>
</body>
</html>