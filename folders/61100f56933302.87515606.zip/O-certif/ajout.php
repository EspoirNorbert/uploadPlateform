<?php
//Appel du fichier de connexion
require_once('connexion_db/conn_db.php');
//Récupération des données par post
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];
$email=$_POST['email'];
$datenaiss=$_POST['datenaiss'];
$id_social=$_POST['social'];
$password= sha1($_POST['password']) ;
//Définition de la requête d'insertion
$sql_ajout="insert into utilisateur values(null,'$nom',
        '$prenom','$email','$datenaiss','$password','$id_social')";
//Exécution de la requête
$query_ajout=mysqli_query($conn,$sql_ajout) or die(mysqli_error($conn));
echo"<h2>Merci $nom! Votre inscription a bien &eacute;t&eacute; prise en compte</h2>
    <a href='inscription.php'>Nouvelle inscription</a>";
?>