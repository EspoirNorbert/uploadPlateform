<?php 
session_start();
if(isset($_SESSION['login'])){//Si la variable session n'a pas �t� cr�ee
    header("location:dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Machi</title>
  <link rel="apple-touch-icon" sizes="180x180" href="img/homeimg/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/homeimg/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/homeimg/favicon-16x16.png">
  <link rel="manifest" href="img/homeimg/site.webmanifest">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
    integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
</head>
<body>
  <!-- entete -->
  <div class="header">
    <nav class="navbar navbar-expand-sm bg-primary navbar-dark fixed-top">
      <a class="navbar-brand text-uppercase text-weight" href="">
        <img src="img/homeimg/favicon.ico" alt="">
        O-certif</a>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-primary btn btn-primary title mr-auto " href="inscription.php">S'inscrire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-primary  btn btn-primary title ml-3" href="connexion.php">Se connecter</a>
        </li>
      </ul>
    </div>
    </nav>
      <div class="container  text-white mt-5">
        <div class="row mt-5">
          <div class="col mt-5 ml-3 border border-primary  " style="background-color: rgba(46, 46, 46, 0.863);">
           <h1 class="title h1 mt-5">Plateforme de passage de certificat</h1>
           <p class="text-left">Comencez des a present a passer des certifications en ligne <br>
            A l'aide de nos formations de qualites dans le domaine cible d'aujourdhui. <br>
            <a href="#" class="btn btn-lg mt-2 btn-outline-primary">Savoir plus</a>
           </p>
          </div>
        </div>
      </div>
   
  </div>
  <div class="container text-white mt-5 mb-5">
    <h2 class="title text-center border border-primary p-3 w-100 mb-5" style="background-color: rgba(46, 46, 46, 0.863);">Categories des domaines de certification</h2>
    <div class="row border border-primary p-4 ">
         <div class="col-md-6 pt-3 border border-primary">
           <img src="img/homeimg/cloud-computing.png"  alt="" class="img-fluid border border-primary">
           <h2 class="text-center pt-2 title">Cloud Computing</h2>
         </div>
         <div class="col-md-6  pt-3 border border-primary">
          <img src="img/homeimg/1606814701-management-de-projet.jpg " alt="" width="400" height="300" class="img-fluid border border-primary img-fluid">
          <h2 class="text-center pt-2 title">Management de projet</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 pt-3 border border-primary">
          <img src="img/homeimg/developpement-de-logiciels.jpg" alt="" class="img-fluid">
          <h2 class="text-center pt-2 title ">Developpement logiciel</h2>
        </div>
       <div class="col-md-6 col-md-6 pt-3 border border-primary">
        <img src="img/homeimg/Cybersécurité-tous-concernés-704x378-vf.png" alt="" class="img-fluid img-fluid border border-primary">
        <h2 class="text-center pt-2 title">Cybersécurité</h2>
      </div>
     </div>
  </div>
  <!-- fin du middle -->
  <div class="footer bg-primary">
    <p>
      Copyright &copy; O-Certif 2021-2022 - All Right reserved
    </p>
  </div>
</body>
</html>