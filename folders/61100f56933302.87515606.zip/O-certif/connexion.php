<?php 
session_start();
if(isset($_SESSION['login'])){//Si la variable session a �t� cr�ee
    header("location:dashboard.php");
    exit();
}
if(isset($_POST['Bconnexion'])){//SI on clique sur le bouton connexion
    //Appel du fichier de connexion � la bd
    require_once('connexion_db/conn_db.php');
    //R�cup�ration des donn�es par la m�thode POST
    $login=$_POST['login'];
    $mdp=$_POST['mdp'];
    $mdpHash=sha1($mdp);
    //D�finition de la requ�te de selection
    $sql_auth="select count(*) nbl from utilisateur where email='$login' and password='$mdpHash'";
    $query_auth=mysqli_query($conn,$sql_auth) or die(mysqli_error($conn));
    $auth=mysqli_fetch_object($query_auth);
    if($auth->nbl==1){//Si l'authentification est correcte
        //Cr�ation d'une variable session
        $_SESSION['login']=$login;
        header("location:dashboard.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Machi</title>
  <link rel="apple-touch-icon" sizes="180x180" href="img/homeimg/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/homeimg/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/homeimg/favicon-16x16.png">
  <link rel="manifest" href="img/homeimg/site.webmanifest">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/style2.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css"
    integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
</head>
<body>
  <!-- entete -->
  <div class="header">
    <nav class="navbar navbar-expand-sm bg-primary navbar-dark fixed-top">
      <a class="navbar-brand text-uppercase text-weight" href="index.php">
        <img src="img/homeimg/favicon.ico" alt="">
        O-certif</a>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link text-primary btn btn-primary title mr-auto " href="inscription.php">S'inscrire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-primary  btn btn-primary title ml-3" href="connexion.php">Se connecter</a>
        </li>
      </ul>
    </div>
    </nav> 
  </div>
  <div class="container text-white mt-5 mb-5">
    <h2 class="title text-center border border-primary p-3 w-100 mb-5" style="background-color: rgba(46, 46, 46, 0.863);">Connexion</h2>
    <form action="" class="border border-primary p-3 bg-dark" method="post">
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="title h4" for="">Email </label>
                        <input type="text" class="form-control" required name="login">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label class="title h4" for="">Password</label>
                        <input type="password" class="form-control" required name="mdp">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="text-center offset-md-5 col-md-2">
                    <button class="btn btn-primary btn-lg" name="Bconnexion" type="submit">Se connecter</button>   
                </div>
                <div class="col-md text-right pt-1">
                    <p>Vous n'avez pas encore de compte ?
                    <a href="inscription.php" class="text-white ">Inscrivez-vous gratuitement</a></p>
                </div>
            </div>
        </form>
  </div>
  <br>
  <!-- fin du middle -->
  <div class="mt-5 footer bg-primary">
    <p>
      Copyright &copy; O-Certif 2021-2022 - All Right reserved
    </p>
  </div>
</body>
</html>