<?php 
session_start();
if(!isset($_SESSION['login'])){//Si la variable session n'a pas été créee
    header("location:index.php");
    exit();
};
$login = $_SESSION['login'];
//Exécution
//Appel du fichier de connexion à la bd
require_once('connexion_db/conn_db.php');
$query_part = $conn->query("select * from utilisateur where email='$login'");
$utilisateur = mysqli_fetch_array($query_part);
extract($utilisateur);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Machi</title>
  <link rel="apple-touch-icon" sizes="180x180" href="img/homeimg/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="img/homeimg/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="img/homeimg/favicon-16x16.png">
  <link rel="manifest" href="img/homeimg/site.webmanifest">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/fontawesome-all.min.css" >
    <link rel="stylesheet" href="css/countries.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Pacifico">
</head>
<body>
    <div class="wrapper">
        <div class="slidebar">
            <h2 class="text-uppercase">O-certif</h2>
            <a href="/">
             <img src="img/homeimg/android-chrome-192x192.png" width="100" class="d-block text-center mx-auto mb-3 border border-primary rounded-circle" alt="">
            </a>
            <ul>
                <li><a href="dashboard.php" id="africa" class="nav-link btn btn-outline-primary">Formation Suivie</a></li>   
                <li><a href="#" id="africa" class="nav-link btn btn-outline-primary">Certificat de formation</a>
            </ul>
            <div class="footer">
                <p>Copyright©2021
                    <a href="sortie.php" class="btn btn-outline-primary title">Deconnecter</a>
                </p>
            </div>
        </div>
    </div>
    <div class="container w-75 float-right">
        <div class="page-header">
            <h1 class="title text-right">Bienvenue  <?= $prenom?></h1>
        </div>
        <hr>
        <h2 class="mt-4 title">Formation de certification</h2> <hr>
        <div class="d-flex justify-content-center border rounded p-3">
            <div class=" bg-dark  flex-fill"><button class="btn p-4 btn-outline-primary" id="dev" >  Developpement Logiciel</button></div>
            <div class=" bg-dark flex-fill"><button class="btn p-4 btn-outline-primary" id="mana">Management de projet</button></div>
            <div class="bg-dark  flex-fill"><button class="btn p-4 btn-outline-primary" id="cloud">Cloud</button></div>
            <div class=" bg-dark flex-fill"><button class="btn p-4 btn-outline-primary" id="cyber">cybersecurité</button></div>

          </div>
        <h2 class="mt-4 title">Tableau de board du suivie des formations  (0 formations) </h2>
          <hr>
            <div class="table-responsive  mb-5">
                <table class="table-content ">
                  <tr>
                      <th>Formation</th>
                      <th>Date Inscription</th>
                      <th>Categorie</th>
                      <th>Examen de Test</th>
                      <th>Certificats</th>
                  </tr>
                  </table>
            </div>
    
    </div>
    <script>
      $(document).ready(function () {
          $("#dev").click(function (e) { 
              window.location.href = "formation.php?formation=1";
          });
          $("#cloud").click(function (e) { 
              window.location.href = "formation.php?formation=3";
          });
          $("#cyber").click(function (e) { 
              window.location.href = "formation.php?formation=4";
          });
          $("#mana").click(function (e) { 
              window.location.href = "formation.php?formation=2";
          });
      });

    </script>
</body>
</html>